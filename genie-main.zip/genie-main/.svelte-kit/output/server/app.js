export { i as init, r as render } from "./chunks/app-28786bd1.js";
