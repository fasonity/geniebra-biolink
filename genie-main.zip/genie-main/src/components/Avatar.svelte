<script>
  export let avartarUrl;
</script>

<div class="avatar">
  <div class="mb-4 w-24 h-24 mask mask-squircle">
    <img src={avartarUrl} alt="Avatar" />
  </div>
</div>
